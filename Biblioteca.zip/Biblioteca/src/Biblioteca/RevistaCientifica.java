package Biblioteca;

class RevistaCientifica extends Material {

    private String areaCientifica;

    public RevistaCientifica() {
    }

    public RevistaCientifica(String codigo, String autor, String titulo, String editorial, Integer anio, String estado) {
        super(codigo, autor, titulo,anio,estado);
        this.areaCientifica = areaCientifica;
    }

    public String getAreaCientifica() {
        return areaCientifica;
    }

    public void setAreaCientifica(String areaCientifica) {
        this.areaCientifica = areaCientifica;
    }

    // Constructor, getters y setters

    @Override
    public String toString() {
        return super.toString() + " [Área Científica: " + areaCientifica + "]";
    }
}