package Biblioteca;

class Prestamo {
    private Material material;
    private Persona prestatario;
    private String fechaSalida;
    private Integer fechaRegreso;

    public Prestamo() {
    }

    public Prestamo(Material material, Persona prestatario, String fechaSalida, Integer fechaRegreso) {
        this.material = material;
        this.prestatario = prestatario;
        this.fechaSalida = fechaSalida;
        this.fechaRegreso = fechaRegreso;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public Persona getPrestatario() {
        return prestatario;
    }

    public void setPrestatario(Persona prestatario) {
        this.prestatario = prestatario;
    }

    public String getFechaSalida() {
        return fechaSalida;
    }

    public void setFechaSalida(String fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    public Integer getFechaRegreso() {
        return fechaRegreso;
    }

    public void setFechaRegreso(Integer fechaRegreso) {
        this.fechaRegreso = fechaRegreso;
    }

    @Override
    public String toString() {
        return "Préstamo de " + material.toString() + " a " + prestatario.toString();
    }
}
