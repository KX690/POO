package Biblioteca;

class Profesor extends Persona {

    private String especialidad;

    public Profesor() {
    }

    public Profesor(Integer codigo, String nombreApellido, String correo, String telefono,String especialidad) {
        super(codigo,nombreApellido,correo,telefono);
        this.especialidad = especialidad;
    }



    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    @Override
    public String toString() {
        return "Biblioteca.Profesor{" +
                "especialidad='" + especialidad + '\'' +
                '}';
    }
}