package Biblioteca;

class Libro extends Material{

    private String editorial;

    public Libro() {
    }

    public Libro(String codigo, String autor, String titulo, String editorial, Integer anio, String estado) {
        super(codigo, autor, titulo,anio,estado);
        this.editorial = editorial;
    }

    public Libro(String editorial) {
        this.editorial = editorial;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    @Override
    public String toString() {
        return super.toString() + " [Editorial: " + editorial + "]";
    }
}