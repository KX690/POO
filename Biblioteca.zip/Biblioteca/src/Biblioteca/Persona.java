package Biblioteca;

abstract class Persona {
    private Integer codigo;
    private String nombreApellido;
    private String correo;
    private String telefono;

    public Persona() {
    }

    public Persona(Integer codigo, String nombreApellido, String correo, String telefono) {
        this.codigo = codigo;
        this.nombreApellido = nombreApellido;
        this.correo = correo;
        this.telefono = telefono;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNombreApellido() {
        return nombreApellido;
    }

    public void setNombreApellido(String nombreApellido) {
        this.nombreApellido = nombreApellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Biblioteca.Persona: " + nombreApellido + " (Código: " + codigo + ")";
    }
}