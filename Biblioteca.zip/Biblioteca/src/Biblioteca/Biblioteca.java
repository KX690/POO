package Biblioteca;

class Biblioteca {
    private String nombre;
    private String horario;
    private Material[] material;
    private Persona[] personas;
    private Prestamo[] prestamos;



    public String varMaterialesPrestados() {
        // Lógica para obtener los materiales prestados

        return "Lista de materiales prestados";
    }

    public void prestarMaterial(Material material, Persona persona) {
        // Lógica para prestar un material a una persona

    }

}