package Biblioteca;

abstract class Material {

    private String codigo;
    private String autor;
    private String titulo;
    private Integer anio;
    private String estado;

    public Material() {
    }

    public Material(String codigo, String autor, String titulo, Integer anio, String estado) {
        this.codigo = codigo;
        this.autor = autor;
        this.titulo = titulo;
        this.anio = anio;
        this.estado = estado;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Integer getAnio() {
        return anio;
    }

    public void setAnio(Integer anio) {
        this.anio = anio;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Biblioteca.Material: " + titulo + " (Autor: " + autor + ")";
    }
}
