package Biblioteca;

class Alumno extends Persona {

    private Integer matricula;

    public Alumno() {
    }
    public Alumno(Integer codigo, String nombreApellido, String correo, String telefono,Integer matricula) {
        super(codigo,nombreApellido,correo,telefono);
        this.matricula=matricula;
    }
    public Alumno(Integer matricula) {

    }

    public Integer getMatricula() {
        return matricula;
    }

    public void setMatricula(Integer matricula) {
        this.matricula = matricula;
    }

    @Override
    public String toString() {
        return "Biblioteca.Alumno{" +
                "matricula=" + matricula +
                '}';
    }
}